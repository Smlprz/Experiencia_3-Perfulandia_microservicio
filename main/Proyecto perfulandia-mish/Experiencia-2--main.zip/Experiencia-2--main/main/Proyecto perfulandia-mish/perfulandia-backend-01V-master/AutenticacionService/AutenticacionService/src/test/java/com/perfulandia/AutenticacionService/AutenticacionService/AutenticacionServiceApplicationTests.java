package com.perfulandia.AutenticacionService.AutenticacionService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutenticacionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
