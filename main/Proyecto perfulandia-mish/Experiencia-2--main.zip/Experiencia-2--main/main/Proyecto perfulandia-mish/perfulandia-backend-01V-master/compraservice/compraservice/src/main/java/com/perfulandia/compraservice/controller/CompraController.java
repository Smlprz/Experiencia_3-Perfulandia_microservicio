package com.perfulandia.compraservice.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import com.perfulandia.compraservice.assembler.CompraAssembler;
import com.perfulandia.compraservice.model.Compra;
import com.perfulandia.compraservice.service.CompraService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/compras")
@Tag(name = "Compra API", description = "Gestión de compras")
public class CompraController {

    private final CompraService compraService;
    private final CompraAssembler assembler;

    public CompraController(CompraService compraService, CompraAssembler assembler) {
        this.compraService = compraService;
        this.assembler = assembler;
    }

    @GetMapping
    @Operation(summary = "Listar compras")
    public CollectionModel<EntityModel<Compra>> listarCompras() {
        List<EntityModel<Compra>> compras = compraService.obtenerTodas().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(compras,
                linkTo(methodOn(CompraController.class).listarCompras()).withSelfRel());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener compra por ID")
    public EntityModel<Compra> obtenerCompra(@PathVariable Long id) {
        Compra compra = compraService.obtenerPorId(id)
                .orElseThrow(() -> new RuntimeException("Compra no encontrada"));
        return assembler.toModel(compra);
    }

    @PostMapping
    @Operation(summary = "Crear nueva compra")
    public ResponseEntity<EntityModel<Compra>> nuevaCompra(@RequestBody Compra compra) {
        EntityModel<Compra> entityModel = assembler.toModel(compraService.registrarCompra(compra));
        return ResponseEntity
                .created(entityModel.getRequiredLink("self").toUri())
                .body(entityModel);
    }

    @PutMapping("/{id}/devolver")
    @Operation(summary = "Marcar como devuelta")
    public EntityModel<Compra> devolverCompra(@PathVariable Long id) {
        return assembler.toModel(compraService.marcarDevuelta(id));
    }

    @PutMapping("/{id}/reembolsar")
    @Operation(summary = "Marcar como reembolsada")
    public EntityModel<Compra> reembolsarCompra(@PathVariable Long id) {
        return assembler.toModel(compraService.marcarReembolsada(id));
    }
}