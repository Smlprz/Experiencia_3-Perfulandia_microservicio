package com.perfulandia.compraservice.service;

import com.perfulandia.compraservice.model.Compra;
import com.perfulandia.compraservice.repository.CompraRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CompraServiceTest {

    @Mock
    private CompraRepository compraRepository;

    @InjectMocks
    private CompraService compraService;

    @Test
    void obtenerPorId_WhenExists_ReturnsCompra() {
        Long id = 1L;
        Compra compra = Compra.builder().id(id).build();
        when(compraRepository.findById(id)).thenReturn(Optional.of(compra));

        Optional<Compra> result = compraService.obtenerPorId(id);

        assertTrue(result.isPresent());
        assertEquals(id, result.get().getId());
        verify(compraRepository, times(1)).findById(id);
    }
}