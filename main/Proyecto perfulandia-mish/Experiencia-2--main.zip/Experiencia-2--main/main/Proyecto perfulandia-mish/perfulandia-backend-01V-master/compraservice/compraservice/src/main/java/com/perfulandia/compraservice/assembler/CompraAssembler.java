package com.perfulandia.compraservice.assembler;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.perfulandia.compraservice.controller.CompraController;
import com.perfulandia.compraservice.model.Compra;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class CompraAssembler implements RepresentationModelAssembler<Compra, EntityModel<Compra>> {
    @Override
    public EntityModel<Compra> toModel(Compra compra) {
        return EntityModel.of(compra,
                linkTo(methodOn(CompraController.class).obtenerCompra(compra.getId())).withSelfRel(),
                linkTo(methodOn(CompraController.class).listarCompras()).withRel("compras"));
    }
}