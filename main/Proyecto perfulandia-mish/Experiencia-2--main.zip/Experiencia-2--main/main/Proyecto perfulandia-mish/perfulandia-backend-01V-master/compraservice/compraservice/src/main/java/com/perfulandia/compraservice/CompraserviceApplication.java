package com.perfulandia.compraservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompraserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompraserviceApplication.class, args);
	}

}
