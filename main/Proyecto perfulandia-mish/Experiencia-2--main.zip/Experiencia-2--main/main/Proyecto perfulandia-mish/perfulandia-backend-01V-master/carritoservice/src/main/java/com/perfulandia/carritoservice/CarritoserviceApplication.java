package com.perfulandia.carritoservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarritoserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarritoserviceApplication.class, args);
	}

}
