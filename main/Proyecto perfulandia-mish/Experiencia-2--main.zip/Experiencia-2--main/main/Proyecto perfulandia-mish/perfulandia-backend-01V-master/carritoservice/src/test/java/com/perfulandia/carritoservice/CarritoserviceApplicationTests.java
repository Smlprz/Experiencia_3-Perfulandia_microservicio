package com.perfulandia.carritoservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarritoserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
