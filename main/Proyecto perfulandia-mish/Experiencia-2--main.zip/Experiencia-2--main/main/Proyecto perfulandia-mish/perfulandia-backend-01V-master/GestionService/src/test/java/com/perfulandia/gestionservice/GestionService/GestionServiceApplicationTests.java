package com.perfulandia.gestionservice.GestionService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionServiceApplicationTests {


	@Test
	void contextLoads() {
	}

}
