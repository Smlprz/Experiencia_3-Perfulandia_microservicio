package com.gestion.gestionservice.repository;

import com.gestion.gestionservice.model.Sucursal;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SucursalRepository extends JpaRepository<Sucursal, String> {

}
