package com.perfulandia.gestionservice.GestionService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionServiceApplication.class, args);
	}

}
